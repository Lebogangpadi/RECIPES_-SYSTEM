﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_System1
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public string Display(double factor)
        {
            string[] ingredients = new string[Ingredients.Count];
            int numIngredient = 0;
            double calories = 0;
            foreach (var ingredient in Ingredients)
            {
                
                string resOutput = $"{numIngredient+1}. {ingredient.Quantity*factor} {ingredient.Unit} of {ingredient.Name}, Calories: {ingredient.Calories*factor}, Food Group: {ingredient.FoodGroup}";
                ingredients[numIngredient] = resOutput;
                numIngredient++;
                calories += ingredient.Calories;
            }
            string recipeIngredients = string.Join("\n", ingredients);

            string[] steps = new string[Steps.Count];
            for (int i = 0; i < Steps.Count; i++)
            {
                string step = $"{i + 1}. {Steps[i].Description}";
                steps[i] = step;    
            }
            string recipeStep = string.Join("\n", steps);
            string recipe = $"Recipe Name: {Name}\nIngredients:\n{recipeIngredients}\n" +
                            $"Calories: {calories*factor} \n {caloryWarning(calories*factor)}\nSteps: \n{recipeStep}\n";
            return recipe;
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            // Implement resetting quantities to original values
        }

        public void Clear()
        {
            Ingredients.Clear();
            Steps.Clear();
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }
            return totalCalories;
        }

        public string caloryWarning(double totalCalories)
        {
            string warning = "";
            if (totalCalories >= 300)
            {
                warning = $"\nWarning: Total calories exceed 300! Total Calories: {totalCalories}";
            }
            return warning;
        }
    }
}
