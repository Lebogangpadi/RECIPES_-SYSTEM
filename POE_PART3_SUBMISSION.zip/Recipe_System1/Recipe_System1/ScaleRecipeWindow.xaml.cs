﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Recipe_System1
{
    /// <summary>
    /// Interaction logic for ScaleRecipeWindow.xaml
    /// </summary>
    public partial class ScaleRecipeWindow : Window
    {
        
        public List<Scale> scales = new List<Scale>();
        public List<Recipe> recipes = new List<Recipe>();
        public ScaleRecipeWindow()
        {
            InitializeComponent();
        }

        private void scale_Click(object sender, RoutedEventArgs e)
        {
            scales.Clear();
            foreach(var recipe in recipes)
            {
                if(recipe.Name == listRecipe.SelectedItem.ToString())
                {
                    if(original.IsChecked == true)
                    {
                        scales.Add(new Scale { Factor = 1,});
                        MessageBox.Show("Recipe Has been scaled to original values");
                        MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                        mainWindow.scales.AddRange(scales);

                        mainWindow.Show();

                    }
                    else if(triple.IsChecked == true)
                    {
                        scales.Add(new Scale { Factor= 3,});
                        MessageBox.Show("Recipe Has been scaled to triple values");
                        MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                        mainWindow.scales.AddRange(scales);
                        mainWindow.Show();

                    }
                    else if(half.IsChecked == true)
                    {
                        scales.Add(new Scale { Factor = 0.5,});
                        MessageBox.Show("Recipe Has been scaled to half values");
                        MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                        mainWindow.scales.AddRange(scales);

                        mainWindow.Show();
                    }
                    else if(doubleScale.IsChecked == true)
                    {
                        scales.Add(new Scale { Factor=2,});
                        MessageBox.Show("Recipe Has been scaled to double values");
                        MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                        mainWindow.scales.AddRange(scales);

                        mainWindow.Show();
                    }
                }
            }
        }

        private void show_Click(object sender, RoutedEventArgs e)
        {
            foreach(var recipe in recipes)
            {
                listRecipe.Items.Add(recipe.Name);
            }
        }
    }
}
