﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Recipe_System1
{
    /// <summary>
    /// Interaction logic for AddRecipeWindow.xaml
    /// </summary>
    public partial class AddRecipeWindow : Window
    {
        public List<Recipe> recipes = new List<Recipe>();
        public List<Ingredient> ingredients = new List<Ingredient>();
        public List<Step> stepsRecipe = new List<Step>();
        public AddRecipeWindow()
        {
            InitializeComponent();
        }

        private void addIngeredient_Click(object sender, RoutedEventArgs e)
        {
            ingredients.Add(new Ingredient
            {
                Name = name.Text,
                Quantity = Convert.ToDouble(quantity.Text),
                Unit = unit.Text,
                Calories = Convert.ToDouble(calories.Text),
                FoodGroup = foodGroup.Text,
            });

            name.Text = string.Empty;
            quantity.Text = string.Empty;   
            unit.Text = string.Empty;
            calories.Text = string.Empty;
            foodGroup.Text = string.Empty;
            name.Focus();
        }

        private void addStep_Click(object sender, RoutedEventArgs e)
        {
            stepsRecipe.Add(new Step
            {
                Description = steps.Text,
            });
            steps.Text = string.Empty;
            steps.Focus();
        }

        private void addRecipe_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void addRecipe_Click_1(object sender, RoutedEventArgs e)
        {
            recipes.Add(new Recipe
            {
                Name = recipeName.Text,
                Ingredients = ingredients,
                Steps = stepsRecipe,
            });

            MessageBox.Show("Recipe Saved Successfully");
            MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
            mainWindow.recipes.AddRange(recipes);
            this.Close();
        }
    }
}
