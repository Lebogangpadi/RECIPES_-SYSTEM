﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_System1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Scale> scales = new List<Scale>();
        public List<Recipe> recipes = new List<Recipe>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            addRecipeWindow.Show();
            
        }

        private void ViewBtn_Click(object sender, RoutedEventArgs e)
        {
            ViewRecipe viewRecipe = new ViewRecipe();
            viewRecipe.scales.AddRange(scales);
            viewRecipe.recipes.AddRange(recipes);
            viewRecipe.Show();
        }

        private void ScaleBtn_Click(object sender, RoutedEventArgs e)
        {
            ScaleRecipeWindow scaleRecipeWindow = new ScaleRecipeWindow();
            scaleRecipeWindow.recipes.AddRange(recipes);
            scaleRecipeWindow.Show();
        }

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}