﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Recipe_System1
{
    /// <summary>
    /// Interaction logic for ViewRecipe.xaml
    /// </summary>
    
    public partial class ViewRecipe : Window
    {
        public List<Recipe> recipes = new List<Recipe>();
        public List<Scale> scales = new List<Scale>();
        public ViewRecipe()
        {
            InitializeComponent();
        }

        private void show_Click(object sender, RoutedEventArgs e)
        {
            
            foreach(var recipe in recipes)
            {
                listRecipe.Items.Add(recipe.Name);
            }

        }

        private void displayButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                if(recipe.Name == listRecipe.SelectedItem.ToString())
                {
                    if (scales.Count == 0)
                    {
                        display.Items.Add($"{recipe.Display(1)}");
                    }
                    else
                    {
                        
                        display.Items.Add($"{recipe.Display(scales[scales.Count-1].Factor)}");
                    }
                    
                }
            }
        }

        private void name_Click(object sender, RoutedEventArgs e)
        {
            foreach(var recipe in recipes)
            {
                foreach(var ingredient in recipe.Ingredients)
                {
                    if(search.Text.Trim() ==  ingredient.Name.Trim())
                    {
                        listRecipe.Items.Add(recipe.Name);
                    }
                }
            }
        }

        private void foodGroup_Click(object sender, RoutedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (search.Text.Trim() == ingredient.FoodGroup.Trim())
                    {
                        listRecipe.Items.Add(recipe.Name);
                    }
                }
            }
        }

        private void calories_Click(object sender, RoutedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (double.Parse(search.Text.Trim()) == ingredient.Calories)
                    {
                        listRecipe.Items.Add(recipe.Name);
                    }
                }
            }
        }
    }
}
